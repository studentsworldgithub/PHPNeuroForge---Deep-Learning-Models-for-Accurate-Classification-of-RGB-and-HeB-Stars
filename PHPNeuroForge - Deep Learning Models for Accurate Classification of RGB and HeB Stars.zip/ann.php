<?php
// This is a demo project created to test PHPNeuroForge.
// This project created by Majdi Awad
// 05/01/2024
require_once 'core/NeuralNetwork.php';

use PHPNeuroForge\Core\NeuralNetwork;

$nn = new NeuralNetwork();

$userInputs = [];
for ($i = 0; $i < $nn->getInputsNumber(); $i++) {
    $value = (float) readline("Enter value for {$nn->getInputsNames()[$i]}: ");
    $userInputs[] = $value;
}

$result = $nn->calculateOutputs($userInputs);
$roundedResult = round($result[0]); 
echo "The calculated output is: $roundedResult";
?>
